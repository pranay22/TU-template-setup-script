# Thesis Template
This project contains the TU Darmstadt thesis template with modifications for theses written at the KOM Lab. Please adhere to this template and *do not* modify any of the formatting parameters, unless instructed to do so!

## Install TU-Darmstadt LaTeX Packages

For unix-based systems you may use the provided script (install-latex-tudesign-unix.sh), otherwise please follow the instructions at exp1.fkp.physik.tu-darmstadt.de/tuddesign/ and https://www.intern.tu-darmstadt.de/arbeitsmittel/corporate_design_vorlagen/index.de.jsp
